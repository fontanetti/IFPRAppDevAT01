package com.example.atividade01;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.RadioButton;

public class MainActivity extends AppCompatActivity {

    private SeekBar skbTamTexto;
    private TextView txtResultado;
    private TextView txtTamTexto;
    private CheckBox chkNegrito;
    private CheckBox chkItalico;
    private CheckBox chkMaiusculas;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnEnvia = findViewById(R.id.btnEnvia);
        TextView txtResultado = findViewById(R.id.textResultado);
        EditText textEntrada = findViewById(R.id.textEntrada);
        SeekBar skbTamTexto = findViewById(R.id.skbTamTexto);
        TextView txtTamTexto = findViewById(R.id.txtTamTexto);
        RadioButton radioVerde = findViewById(R.id.radioVerde);
        RadioButton radioVermelho = findViewById(R.id.radioVermelho);
        RadioButton radioAzul = findViewById(R.id.radioAzul);

        btnEnvia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txtResultado.setText(textEntrada.getText());
            }
        });

        //skbTamTexto.setOnSeekBarChangeListener(this);
        skbTamTexto.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                txtTamTexto.setText(i + "sp");
                txtResultado.setTextSize(i);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        CheckBox chkNegrito = findViewById(R.id.chkNegrito);
        CheckBox chkItalico = findViewById(R.id.chkItalico);
        CheckBox chkMaiusculas = findViewById(R.id.chkMaiusculas);

        chkNegrito.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (chkNegrito.isChecked()) {
                    if (chkItalico.isChecked()) {
                        //Negrito e Itálico
                        txtResultado.setTypeface(null, Typeface.BOLD_ITALIC);
                    }else{
                        //Negrito
                        txtResultado.setTypeface(null, Typeface.BOLD);
                    }
                }else{
                    if (chkItalico.isChecked()) {
                        //Itálico
                        txtResultado.setTypeface(null, Typeface.ITALIC);
                    }else{
                        //Normal
                        txtResultado.setTypeface(null, Typeface.NORMAL);
                    }
                }
            }
        });
        chkItalico.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (chkNegrito.isChecked()) {
                    if (chkItalico.isChecked()) {
                        //Negrito e Itálico
                        txtResultado.setTypeface(null, Typeface.BOLD_ITALIC);
                    }else{
                        //Negrito
                        txtResultado.setTypeface(null, Typeface.BOLD);
                    }
                }else{
                    if (chkItalico.isChecked()) {
                        //Itálico
                        txtResultado.setTypeface(null, Typeface.ITALIC);
                    }else{
                        //Normal
                        txtResultado.setTypeface(null, Typeface.NORMAL);
                    }
                }
            }
        });
        chkMaiusculas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Coloca tudo em maiúsculo
                if (chkMaiusculas.isChecked()) {
                    txtResultado.setAllCaps(true);
                }else {
                    txtResultado.setAllCaps(false);
                }
            }
        });

        radioVerde.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (radioVerde.isChecked()){
                    txtResultado.setTextColor(Color.parseColor("#00FF00"));
                }
                if (radioVermelho.isChecked()){
                    txtResultado.setTextColor(Color.parseColor("#FF0000"));
                }
                if (radioAzul.isChecked()){
                    txtResultado.setTextColor(Color.parseColor("#0000FF"));
                }
            }
        });

        radioVermelho.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (radioVerde.isChecked()){
                    txtResultado.setTextColor(Color.parseColor("#00FF00"));
                }
                if (radioVermelho.isChecked()){
                    txtResultado.setTextColor(Color.parseColor("#FF0000"));
                }
                if (radioAzul.isChecked()){
                    txtResultado.setTextColor(Color.parseColor("#0000FF"));
                }
            }
        });

        radioAzul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (radioVerde.isChecked()){
                    txtResultado.setTextColor(Color.parseColor("#00FF00"));
                }
                if (radioVermelho.isChecked()){
                    txtResultado.setTextColor(Color.parseColor("#FF0000"));
                }
                if (radioAzul.isChecked()){
                    txtResultado.setTextColor(Color.parseColor("#0000FF"));
                }
            }
        });
    }
}